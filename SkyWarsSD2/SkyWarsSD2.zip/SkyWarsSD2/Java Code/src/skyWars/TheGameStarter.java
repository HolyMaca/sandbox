package skyWars;

public class TheGameStarter {

	public static void main(String[] args) {
		
		TheSkyWarsGUI startGame = new TheSkyWarsGUI();
		startGame.setVisible(true);

	}

}
