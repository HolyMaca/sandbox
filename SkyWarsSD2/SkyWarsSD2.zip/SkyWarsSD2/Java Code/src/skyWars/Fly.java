package skyWars;

public interface Fly {
	
	public void fly(Sky theSky);

}
