package skyWars;

public interface Observer {
	
	public void receiveUpdate(Sky theSky);

}
