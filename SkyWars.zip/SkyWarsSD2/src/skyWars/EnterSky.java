package skyWars;

public interface EnterSky {
	
	public void enterSky(Sky theSky);

}
