package skyWars;

public interface MasterShipMode {
	
	public int mode();

}
