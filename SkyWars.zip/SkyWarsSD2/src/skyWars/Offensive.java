package skyWars;

public class Offensive implements MasterShipMode {

	public int mode() {
		
		return 2;
	}

}
