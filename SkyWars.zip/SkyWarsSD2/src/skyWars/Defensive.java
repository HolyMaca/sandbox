package skyWars;

public class Defensive implements MasterShipMode {

	public int mode() {
		
		return 1;
	}

}
